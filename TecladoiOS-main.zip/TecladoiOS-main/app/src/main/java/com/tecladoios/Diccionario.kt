package com.tecladoios

import java.io.BufferedReader

/**
 * Diccionario en un árbol de letras compacto (solo arreglos de números, sin objetos por
 * letra): buscar con errores, completar y sugerir es rápido y gasta poca memoria.
 *
 * Cada palabra tiene un número: 0 es la más usada. El costo de frecuencia sale de ese número.
 * Las claves del árbol van sin tildes y en minúsculas; la palabra guardada sí las tiene.
 */
class Diccionario private constructor(
    val palabras: Array<String>,
    val claves: Array<String>,
    private val penal: FloatArray,
    // Árbol
    val letra: CharArray,
    val hijo: IntArray,
    val hermano: IntArray,
    val terminal: IntArray,
    val mejor: IntArray,
    private val otras: HashMap<String, IntArray>,
    /** Palabras que solo existen en otro idioma (inglés, portugués) */
    private val extranjera: BooleanArray,
) {
    /** La palabra solo es de otro idioma: no le gana a una del español salvo que la uses */
    fun esExtranjera(id: Int): Boolean = id in extranjera.indices && extranjera[id]

    val total get() = palabras.size

    /** Costo por ser poco común (0 = de las más usadas) */
    fun penal(id: Int): Float = penal[id]

    /** Nodo del árbol para una clave exacta o -1 */
    fun nodo(clave: CharSequence): Int {
        var n = 0
        for (ch in clave) {
            var h = hijo[n]
            while (h >= 0 && letra[h] != ch) h = hermano[h]
            if (h < 0) return -1
            n = h
        }
        return n
    }

    /** Todas las palabras con esa clave (\"esta\" → está, esta, ésta), de más a menos usada */
    fun formas(clave: String): IntArray {
        otras[clave]?.let { return it }
        val n = nodo(clave)
        if (n < 0 || terminal[n] < 0) return IntArray(0)
        return intArrayOf(terminal[n])
    }

    fun existe(clave: String) = formas(clave).isNotEmpty()

    fun id(palabra: String): Int {
        val f = formas(Texto.normal(palabra))
        for (i in f) if (palabras[i] == palabra) return i
        for (i in f) if (palabras[i].equals(palabra, ignoreCase = true)) return i
        return -1
    }

    /** Las [k] palabras más usadas que empiezan en el nodo [desde] */
    fun completar(desde: Int, k: Int, salida: (Int) -> Unit) {
        if (desde < 0) return
        // Cola por número de palabra: nodos (positivos) y palabras (codificadas como -1 - id)
        val cola = java.util.PriorityQueue<Long>(32)
        fun meter(clave: Int, valor: Int) { cola.add((clave.toLong() shl 32) or (valor.toLong() and 0xFFFFFFFFL)) }
        meter(mejor[desde], desde)
        var dados = 0
        while (cola.isNotEmpty() && dados < k) {
            val x = cola.poll()!!
            val v = (x and 0xFFFFFFFFL).toInt()
            if (v < 0) { salida(-1 - v); dados++; continue }
            if (terminal[v] >= 0) meter(terminal[v], -1 - terminal[v])
            var h = hijo[v]
            while (h >= 0) { if (mejor[h] < Int.MAX_VALUE) meter(mejor[h], h); h = hermano[h] }
        }
    }

    /**
     * Guarda el diccionario ya armado en un archivo binario: la próxima vez se carga en una
     * fracción del tiempo (arranque casi instantáneo). [marca] identifica la versión del APK.
     */
    fun guardar(archivo: java.io.File, marca: Long) {
        val tmp = java.io.File(archivo.parentFile, archivo.name + ".tmp")
        java.io.DataOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(tmp), 1 shl 16)).use { o ->
            o.writeInt(MAGIA); o.writeLong(marca)
            o.writeInt(palabras.size); o.writeInt(letra.size)
            val texto = palabras.joinToString("\n").toByteArray(Charsets.UTF_8)
            o.writeInt(texto.size); o.write(texto)
            val bp = java.nio.ByteBuffer.allocate(penal.size * 4); bp.asFloatBuffer().put(penal); o.write(bp.array())
            val bl = java.nio.ByteBuffer.allocate(letra.size * 2); bl.asCharBuffer().put(letra); o.write(bl.array())
            for (arr in arrayOf(hijo, hermano, terminal, mejor)) {
                val b = java.nio.ByteBuffer.allocate(arr.size * 4); b.asIntBuffer().put(arr); o.write(b.array())
            }
            o.writeInt(otras.size)
            for ((k, ids) in otras) { o.writeUTF(k); o.writeInt(ids.size); for (i in ids) o.writeInt(i) }
            o.write(ByteArray(extranjera.size) { if (extranjera[it]) 1 else 0 })
        }
        if (!tmp.renameTo(archivo)) { archivo.delete(); tmp.renameTo(archivo) }
    }

    companion object {
        private const val MAGIA = 0x54504432  // "TPD2" (con la marca de otros idiomas)

        /** Lee el diccionario guardado; null si no existe, está dañado o es de otra versión */
        fun leer(archivo: java.io.File, marca: Long): Diccionario? {
            if (!archivo.exists()) return null
            return try {
                java.io.DataInputStream(java.io.BufferedInputStream(java.io.FileInputStream(archivo), 1 shl 16)).use { e ->
                    if (e.readInt() != MAGIA || e.readLong() != marca) return null
                    val n = e.readInt(); val nodos = e.readInt()
                    val texto = ByteArray(e.readInt()); e.readFully(texto)
                    val palabras = String(texto, Charsets.UTF_8).split('\n').toTypedArray()
                    if (palabras.size != n) return null
                    fun bytes(k: Int) = ByteArray(k).also { e.readFully(it) }
                    val penal = FloatArray(n).also { java.nio.ByteBuffer.wrap(bytes(n * 4)).asFloatBuffer().get(it) }
                    val letra = CharArray(nodos).also { java.nio.ByteBuffer.wrap(bytes(nodos * 2)).asCharBuffer().get(it) }
                    fun enteros() = IntArray(nodos).also { java.nio.ByteBuffer.wrap(bytes(nodos * 4)).asIntBuffer().get(it) }
                    val hijo = enteros(); val hermano = enteros(); val terminal = enteros(); val mejor = enteros()
                    val otras = HashMap<String, IntArray>()
                    repeat(e.readInt()) {
                        val k = e.readUTF()
                        otras[k] = IntArray(e.readInt()) { e.readInt() }
                    }
                    val extranjera = BooleanArray(n).also { val b = bytes(n); for (i in 0 until n) it[i] = b[i].toInt() != 0 }
                    val claves = Array(n) { val p = palabras[it]; val c = Texto.normal(p); if (c == p) p else c }
                    Diccionario(palabras, claves, penal, letra, hijo, hermano, terminal, mejor, otras, extranjera)
                }
            } catch (ex: Throwable) {
                Registro.anotar("leer diccionario guardado", ex)
                null
            }
        }

        private val RAIZ_BASE = Math.log(30.0).toFloat()

        class Fuente(val lector: () -> BufferedReader?, val extraPenal: Float, val multiplica: Int)

        /**
         * Arma el diccionario. [principal] da las palabras en orden de uso (la primera es la
         * más común); [otras] son otros idiomas, que pesan menos.
         */
        fun armar(principal: List<String>, otrosIdiomas: List<Pair<List<String>, Float>>): Diccionario {
            // 1) Palabras con su costo, sin repetir
            val costo = HashMap<String, Float>(principal.size + 60000)
            principal.forEachIndexed { r, w ->
                if (w.isNotEmpty() && !costo.containsKey(w))
                    costo[w] = (Math.log(r + 30.0).toFloat() - RAIZ_BASE)
            }
            // Las del español (sin tildes ni mayúsculas) para saber cuáles son solo de otro idioma
            val espanol = HashSet<String>(costo.size * 2)
            for (w in costo.keys) espanol.add(Texto.normal(w))
            val deFuera = HashSet<String>()
            for ((lista, extra) in otrosIdiomas) {
                lista.forEachIndexed { r, w ->
                    if (w.isEmpty()) return@forEachIndexed
                    val c = Math.log(r * 3.0 + 30.0).toFloat() - RAIZ_BASE + extra
                    val previo = costo[w]
                    if (previo == null || c < previo) costo[w] = c
                    if (Texto.normal(w) !in espanol) deFuera.add(w)
                }
            }
            // 2) Número de cada palabra = su lugar por costo
            val ordenadas = costo.entries.sortedBy { it.value }
            val n = ordenadas.size
            val palabras = Array(n) { ordenadas[it].key }
            val penal = FloatArray(n) { ordenadas[it].value }
            val claves = Array(n) { val p = palabras[it]; val c = Texto.normal(p); if (c == p) p else c }
            val extranjera = BooleanArray(n) { palabras[it] in deFuera }

            // 3) Árbol: se meten las claves en orden alfabético
            val porClave = (0 until n).sortedWith { a, b -> claves[a].compareTo(claves[b]) }
            var cap = 1 shl 16
            var letra = CharArray(cap)
            var hijo = IntArray(cap)
            var hermano = IntArray(cap)
            var terminal = IntArray(cap)
            var padre = IntArray(cap)
            var ultimo = IntArray(cap)
            var nodos = 1
            hijo[0] = -1; hermano[0] = -1; terminal[0] = -1; padre[0] = -1; ultimo[0] = -1
            val otras = HashMap<String, IntArray>()
            val camino = IntArray(64)
            var anterior = ""
            for (id in porClave) {
                val k = claves[id]
                if (k.isEmpty() || k.length >= 60) continue
                var comun = 0
                val lim = minOf(k.length, anterior.length)
                while (comun < lim && k[comun] == anterior[comun]) comun++
                if (comun == k.length && comun == anterior.length) {
                    // Misma clave: otra forma de la misma palabra (tildes o mayúsculas)
                    val nodo = camino[k.length]
                    val previo = terminal[nodo]
                    val lista = otras[k]?.toMutableList() ?: mutableListOf(previo)
                    lista.add(id)
                    lista.sort()
                    otras[k] = lista.toIntArray()
                    if (id < previo) terminal[nodo] = id
                    continue
                }
                camino[0] = 0
                var actual = camino[comun]
                for (i in comun until k.length) {
                    if (nodos == cap) {
                        cap *= 2
                        letra = letra.copyOf(cap); hijo = hijo.copyOf(cap); hermano = hermano.copyOf(cap)
                        terminal = terminal.copyOf(cap); padre = padre.copyOf(cap); ultimo = ultimo.copyOf(cap)
                    }
                    val nuevo = nodos++
                    letra[nuevo] = k[i]; hijo[nuevo] = -1; hermano[nuevo] = -1; terminal[nuevo] = -1
                    ultimo[nuevo] = -1; padre[nuevo] = actual
                    if (hijo[actual] < 0) hijo[actual] = nuevo else hermano[ultimo[actual]] = nuevo
                    ultimo[actual] = nuevo
                    actual = nuevo
                    camino[i + 1] = nuevo
                }
                terminal[actual] = id
                anterior = k
            }
            // 4) La palabra más usada debajo de cada nodo (para completar rápido)
            val mejor = IntArray(nodos) { if (terminal[it] >= 0) terminal[it] else Int.MAX_VALUE }
            for (i in nodos - 1 downTo 1) {
                val p = padre[i]
                if (mejor[i] < mejor[p]) mejor[p] = mejor[i]
            }
            return Diccionario(
                palabras, claves, penal,
                letra.copyOf(nodos), hijo.copyOf(nodos), hermano.copyOf(nodos), terminal.copyOf(nodos),
                mejor, otras, extranjera
            )
        }
    }
}
